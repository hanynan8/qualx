// app/services/[slug]/page.js
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowRight, ArrowLeft, Check } from "lucide-react";
import { getServiceBySlug, getServices } from "../../../lib/data";
import ServiceIcon from "../../../components/ServiceIcon";

export async function generateStaticParams() {
  const services = await getServices();
  return services.map((service) => ({ slug: service.slug }));
}

export async function generateMetadata({ params }) {
  const service = await getServiceBySlug(params.slug);
  if (!service) return {};
  return {
    title: `${service.title} — Qualx`,
    description: service.short,
  };
}

export default async function ServiceDetailPage({ params }) {
  const [service, allServices] = await Promise.all([
    getServiceBySlug(params.slug),
    getServices(),
  ]);

  if (!service) notFound();

  const otherServices = allServices.filter((s) => s.slug !== service.slug);

  return (
    <div>
      <section className="bg-navy text-offwhite">
        <div className="container-content py-20">
          <Link
            href="/services"
            className="inline-flex items-center gap-2 text-sm text-offwhite/70 hover:text-gold"
          >
            <ArrowLeft size={14} />
            All services
          </Link>

          <div className="mt-6 flex h-14 w-14 items-center justify-center rounded bg-gold text-navy">
            <ServiceIcon name={service.icon} size={26} />
          </div>

          <h1 className="mt-6 max-w-2xl font-display text-4xl font-semibold leading-tight">
            {service.title}
          </h1>
          <p className="mt-4 max-w-xl text-offwhite/75">{service.short}</p>
        </div>
      </section>

      <section className="container-content grid gap-12 py-16 md:grid-cols-3">
        <div className="md:col-span-2">
          <h2 className="font-display text-xl font-semibold text-navy">
            How it works
          </h2>
          <p className="mt-4 leading-relaxed text-charcoal/80">
            {service.description}
          </p>

          <Link href="/services" className="btn-primary mt-8">
            Ask about this service
            <ArrowRight size={16} />
          </Link>
        </div>

        <div>
          <div className="rounded-lg border border-charcoal/10 bg-white p-6">
            <h3 className="font-display text-base font-semibold text-navy">
              What's included
            </h3>
            <ul className="mt-4 space-y-3">
              {service.highlights.map((item) => (
                <li key={item} className="flex items-start gap-3 text-sm text-charcoal/75">
                  <Check size={16} className="mt-0.5 shrink-0 text-sky" />
                  {item}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      <section className="border-t border-charcoal/10 bg-white">
        <div className="container-content py-16">
          <h2 className="font-display text-xl font-semibold text-navy">
            Other services
          </h2>
          <div className="mt-6 grid gap-6 sm:grid-cols-3">
            {otherServices.map((s) => (
              <Link
                key={s.slug}
                href={`/services/${s.slug}`}
                className="group rounded-lg border border-charcoal/10 p-5 transition-colors hover:border-sky"
              >
                <div className="flex h-9 w-9 items-center justify-center rounded bg-navy text-gold">
                  <ServiceIcon name={s.icon} size={18} />
                </div>
                <h3 className="mt-4 font-display text-base font-semibold text-navy">
                  {s.title}
                </h3>
                <span className="mt-2 inline-block text-sm font-medium text-sky group-hover:text-navy">
                  Learn more →
                </span>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}