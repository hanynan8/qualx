// app/services/page.js
import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { getServices } from "../../lib/data";
import ServiceIcon from "../../components/ServiceIcon";

export const metadata = {
  title: "Services — Qualx",
  description:
    "Mystery Shopping, Auditing Visits, Managed Services, and Customer Experience — how Qualx helps businesses across Egypt see and improve the customer experience they deliver.",
};

export default async function ServicesPage() {
  const services = await getServices();

  return (
    <div>
      <section className="bg-navy text-offwhite">
        <div className="container-content py-20">
          <span className="inline-block rounded-full border border-gold/40 px-3 py-1 text-xs font-medium text-gold">
            Our services
          </span>
          <h1 className="mt-6 max-w-2xl font-display text-4xl font-semibold leading-tight">
            Four ways we help you see, and improve, the customer experience.
          </h1>
          <p className="mt-4 max-w-xl text-offwhite/75">
            From a single confidential visit to a fully managed quality
            department, every service is built to turn real customer
            experience into evidence, and evidence into action.
          </p>
        </div>
      </section>

      <section className="container-content py-16">
        <div className="grid gap-8 md:grid-cols-2">
          {services.map((service) => (
            <div
              key={service.slug}
              className="flex flex-col rounded-lg border border-charcoal/10 bg-white p-8"
            >
              <div className="flex h-12 w-12 items-center justify-center rounded bg-navy text-gold">
                <ServiceIcon name={service.icon} size={24} />
              </div>
              <h2 className="mt-6 font-display text-xl font-semibold text-navy">
                {service.title}
              </h2>
              <p className="mt-3 flex-1 text-sm leading-relaxed text-charcoal/70">
                {service.short}
              </p>
              <Link
                href={`/services/${service.slug}`}
                className="mt-6 inline-flex items-center gap-2 text-sm font-semibold text-sky hover:text-navy"
              >
                See how it works
                <ArrowRight size={16} />
              </Link>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}