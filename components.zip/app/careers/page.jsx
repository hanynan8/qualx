// app/careers/page.js
import { Briefcase, MapPin, ArrowRight } from "lucide-react";
import { getCareers, getCompanyInfo } from "@/lib/data";

export const metadata = {
  title: "Careers — Qualx",
  description:
    "Open roles at Qualx — join the team evaluating and improving customer experience for businesses across Egypt.",
};

export default async function CareersPage() {
  const [careers, company] = await Promise.all([getCareers(), getCompanyInfo()]);

  return (
    <div>
      <section className="bg-navy text-offwhite">
        <div className="container-content py-20">
          <span className="inline-block rounded-full border border-gold/40 px-3 py-1 text-xs font-medium text-gold">
            Careers
          </span>
          <h1 className="mt-6 max-w-2xl font-display text-4xl font-semibold leading-tight">
            Help businesses see themselves the way their customers do.
          </h1>
          <p className="mt-4 max-w-xl text-offwhite/75">
            We're a small, sharp team working across Egypt on Mystery
            Shopping, Auditing, and Customer Experience. If you notice
            details other people miss, we'd like to hear from you.
          </p>
        </div>
      </section>

      <section className="container-content py-16">
        <h2 className="font-display text-xl font-semibold text-navy">
          Open roles
        </h2>

        <div className="mt-8 space-y-4">
          {careers.map((role) => (
            <div
              key={role.slug}
              className="flex flex-col gap-4 rounded-lg border border-charcoal/10 bg-white p-6 sm:flex-row sm:items-center sm:justify-between"
            >
              <div>
                <h3 className="font-display text-lg font-semibold text-navy">
                  {role.title}
                </h3>
                <div className="mt-2 flex flex-wrap gap-4 text-sm text-charcoal/60">
                  <span className="flex items-center gap-1.5">
                    <Briefcase size={15} className="text-sky" />
                    {role.type}
                  </span>
                  <span className="flex items-center gap-1.5">
                    <MapPin size={15} className="text-sky" />
                    {role.location}
                  </span>
                </div>
                <p className="mt-3 max-w-xl text-sm text-charcoal/70">
                  {role.description}
                </p>
              </div>

              <a
                href={`mailto:${company.email}?subject=${encodeURIComponent(
                  "Application: " + role.title
                )}`}
                className="btn-primary shrink-0 self-start sm:self-center"
              >
                Apply now
                <ArrowRight size={16} />
              </a>
            </div>
          ))}
        </div>

        <div className="mt-10 rounded-lg bg-sky/10 p-6 text-sm text-charcoal/70">
          Don't see a role that fits? Send your CV to{" "}
          <a href={`mailto:${company.email}`} className="font-medium text-sky hover:text-navy">
            {company.email}
          </a>{" "}
          and tell us where you'd add the most value.
        </div>
      </section>
    </div>
  );
}