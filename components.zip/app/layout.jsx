import "./globals.css";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
import { getCompanyInfo } from "../lib/data";

export const metadata = {
  title: "Qualx — Quality Assurance & Customer Experience",
  description:
    "Qualx evaluates customer experience and quality control for businesses across Egypt through Mystery Shopping, Auditing, Managed Services, and CX consulting.",
};

export default async function RootLayout({ children }) {
  const company = await getCompanyInfo();

  return (
    <html lang="en">
      <body className="flex min-h-screen flex-col bg-offwhite text-charcoal antialiased">
        <Navbar company={company} />
        <main className="flex-1">{children}</main>
        <Footer company={company} />
      </body>
    </html>
  );
}