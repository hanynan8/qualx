// app/page.js
import Link from "next/link";
import { ArrowRight, ShieldCheck, Users2, ClipboardList } from "lucide-react";
import { getServices, getCompanyInfo } from "../lib/data";
import ServiceIcon from "../components/ServiceIcon";

export default async function HomePage() {
  const services = await getServices();
  const company = await getCompanyInfo();

  return (
    <div>
      {/* Hero */}
      <section className="bg-navy text-offwhite">
        <div className="container-content grid items-center gap-12 py-24 md:grid-cols-2 md:py-32">
          <div>
            <span className="inline-block rounded-full border border-gold/40 px-3 py-1 text-xs font-medium text-gold">
              Mystery Shopping · Auditing · CX
            </span>
            <h1 className="mt-6 font-display text-4xl font-semibold leading-tight md:text-5xl">
              See your business the way your customers actually see it.
            </h1>
            <p className="mt-6 max-w-lg text-offwhite/75">
              {company.summary}
            </p>
            <div className="mt-8 flex flex-wrap gap-4">
              <Link href="/services" className="btn-primary">
                Explore our services
                <ArrowRight size={16} />
              </Link>
              <Link href="/careers" className="btn-secondary">
                Join our team
              </Link>
            </div>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div className="rounded-lg bg-white/5 p-6">
              <ShieldCheck className="text-sky" size={28} />
              <p className="mt-4 text-sm text-offwhite/80">
                Confidential, structured evaluation visits across Egypt
              </p>
            </div>
            <div className="mt-6 rounded-lg bg-white/5 p-6 sm:mt-12">
              <Users2 className="text-sky" size={28} />
              <p className="mt-4 text-sm text-offwhite/80">
                A dedicated quality team, embedded in your operation
              </p>
            </div>
            <div className="rounded-lg bg-white/5 p-6">
              <ClipboardList className="text-sky" size={28} />
              <p className="mt-4 text-sm text-offwhite/80">
                Documented findings turned into real, actionable plans
              </p>
            </div>
            <div className="mt-6 rounded-lg border border-gold/30 bg-gold/10 p-6 sm:mt-12">
              <p className="font-display text-2xl font-semibold text-gold">USP</p>
              <p className="mt-2 text-sm text-offwhite/80">
                Built from a real understanding of the Egyptian market
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Who we are */}
      <section className="border-b border-charcoal/10 bg-white">
        <div className="container-content grid gap-10 py-20 md:grid-cols-3">
          <div>
            <h2 className="font-display text-2xl font-semibold text-navy">
              Who we are
            </h2>
          </div>
          <div className="md:col-span-2">
            <p className="text-charcoal/80 leading-relaxed">
              {company.summary}
            </p>
          </div>
        </div>
      </section>

      {/* Services preview */}
      <section className="container-content py-20">
        <div className="mb-10 flex flex-wrap items-end justify-between gap-4">
          <h2 className="font-display text-2xl font-semibold text-navy">
            What we do
          </h2>
          <Link href="/services" className="text-sm font-medium text-sky hover:text-navy">
            View all services →
          </Link>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          {services.map((service) => (
            <Link
              key={service.slug}
              href={`/services/${service.slug}`}
              className="group flex flex-col rounded-lg border border-charcoal/10 bg-white p-6 transition-colors hover:border-sky"
            >
              <div className="flex h-11 w-11 items-center justify-center rounded bg-navy text-gold">
                <ServiceIcon name={service.icon} />
              </div>
              <h3 className="mt-5 font-display text-lg font-semibold text-navy">
                {service.title}
              </h3>
              <p className="mt-2 flex-1 text-sm text-charcoal/70">
                {service.short}
              </p>
              <span className="mt-4 text-sm font-medium text-sky group-hover:text-navy">
                Learn more →
              </span>
            </Link>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="bg-sky/10">
        <div className="container-content flex flex-col items-start justify-between gap-6 py-16 md:flex-row md:items-center">
          <div>
            <h2 className="font-display text-2xl font-semibold text-navy">
              Ready to see your business through your customers' eyes?
            </h2>
            <p className="mt-2 text-charcoal/70">
              Tell us about your branches — we'll put together a plan.
            </p>
          </div>
          <Link href="/services" className="btn-primary">
            Get in touch
            <ArrowRight size={16} />
          </Link>
        </div>
      </section>
    </div>
  );
}