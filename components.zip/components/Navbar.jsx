// components/Navbar.js
"use client";

import Link from "next/link";
import { useState } from "react";
import { Menu, X } from "lucide-react";

const NAV_LINKS = [
  { href: "/", label: "Home" },
  { href: "/services", label: "Services" },
  { href: "/careers", label: "Careers" },
];

export default function Navbar({ company }) {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 bg-navy text-offwhite">
      <div className="container-content flex h-16 items-center justify-between">
        <Link href="/" className="flex items-center gap-2 font-display text-xl font-semibold tracking-wide">
          <span className="flex h-8 w-8 items-center justify-center rounded bg-gold text-navy">
            Q
          </span>
          {company?.name || "Qualx"}
        </Link>

        <nav className="hidden items-center gap-8 md:flex">
          {NAV_LINKS.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className="text-sm font-medium text-offwhite/85 transition-colors hover:text-gold"
            >
              {link.label}
            </Link>
          ))}
          <Link href="/services" className="btn-primary text-sm">
            Get a quote
          </Link>
        </nav>

        <button
          aria-label={open ? "Close menu" : "Open menu"}
          className="text-offwhite md:hidden"
          onClick={() => setOpen((v) => !v)}
        >
          {open ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {open && (
        <div className="border-t border-offwhite/10 bg-navy md:hidden">
          <div className="container-content flex flex-col gap-1 py-3">
            {NAV_LINKS.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                onClick={() => setOpen(false)}
                className="rounded px-2 py-2 text-sm font-medium text-offwhite/90 hover:bg-offwhite/5"
              >
                {link.label}
              </Link>
            ))}
            <Link
              href="/services"
              onClick={() => setOpen(false)}
              className="mt-2 inline-block rounded bg-gold px-4 py-2 text-center text-sm font-semibold text-navy"
            >
              Get a quote
            </Link>
          </div>
        </div>
      )}
    </header>
  );
}