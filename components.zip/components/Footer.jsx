// components/Footer.js
import Link from "next/link";
import { Mail, Phone, MapPin } from "lucide-react";

export default function Footer({ company }) {
  const year = new Date().getFullYear();

  return (
    <footer className="bg-navy text-offwhite/80">
      <div className="container-content grid gap-10 py-14 md:grid-cols-4">
        <div className="md:col-span-2">
          <div className="flex items-center gap-2 font-display text-xl font-semibold text-offwhite">
            <span className="flex h-8 w-8 items-center justify-center rounded bg-gold text-navy">
              Q
            </span>
            {company?.name || "Qualx"}
          </div>
          <p className="mt-4 max-w-sm text-sm leading-relaxed text-offwhite/70">
            {company?.tagline || "Quality Assurance & Customer Experience"} for
            businesses and branches across Egypt — Mystery Shopping,
            Auditing, Managed Services, and CX.
          </p>
        </div>

        <div>
          <h3 className="mb-4 text-sm font-semibold uppercase tracking-wide text-gold">
            Company
          </h3>
          <ul className="space-y-2 text-sm">
            <li><Link href="/" className="hover:text-gold">Home</Link></li>
            <li><Link href="/services" className="hover:text-gold">Services</Link></li>
            <li><Link href="/careers" className="hover:text-gold">Careers</Link></li>
          </ul>
        </div>

        <div>
          <h3 className="mb-4 text-sm font-semibold uppercase tracking-wide text-gold">
            Contact
          </h3>
          <ul className="space-y-3 text-sm">
            <li className="flex items-center gap-2">
              <Mail size={16} className="text-sky" />
              {company?.email || "hello@qualx.com"}
            </li>
            <li className="flex items-center gap-2">
              <Phone size={16} className="text-sky" />
              {company?.phone || "+20 100 000 0000"}
            </li>
            <li className="flex items-center gap-2">
              <MapPin size={16} className="text-sky" />
              {company?.location || "Cairo, Egypt"}
            </li>
          </ul>
        </div>
      </div>

      <div className="border-t border-offwhite/10 py-6">
        <p className="container-content text-center text-xs text-offwhite/50">
          © {year} {company?.name || "Qualx"}. All rights reserved.
        </p>
      </div>
    </footer>
  );
}